# Function to check if a number is prime
def is_prime(n):
    if n <= 1:
        return False            # 0 and 1 are not prime numbers
    if n == 2:
        return True             # 2 is the smallest prime number
    if n % 2 == 0:
        return False            # Even numbers greater than 2 are not prime
    for i in range(3, int(n**0.5) + 1, 2):  # Check divisibility up to the square root of n
        if n % i == 0:
            return False        # If divisible by any number, it is not prime
    return True                 # Otherwise, it is a prime number

# Class to simulate a simple Turing Machine
class TuringMachine:
    def __init__(self, tape):
        self.tape = list(tape)  # Convert the input string (unary) into a list of symbols
        self.head = 0           # Head starts at the beginning of the tape
        self.state = 'q0'       # Initial state of the machine
        self.count = 0          # Counter to count the number of '1's on the tape

    # One step of the Turing Machine
    def step(self):
        if self.state == 'q0':
            # In state q0, move right and count the number of '1's
            if self.head < len(self.tape) and self.tape[self.head] == '1':
                self.count += 1     # Increment counter for each '1'
                self.head += 1      # Move head to the right
            else:
                # When a non-'1' or end of tape is found, go to prime-checking state
                self.state = 'check_prime'

        elif self.state == 'check_prime':
            self.result = is_prime(self.count)  # Check if the count is a prime number
            self.state = 'halt'                 # Transition to halting state

    # Run the Turing Machine until it halts
    def run(self):
        while self.state != 'halt':
            self.step()
        return self.result  # Return True if input length is prime, else False
