# test_turing.py

import unittest
from turing import TuringMachine

class TestTuringMachine(unittest.TestCase):

    def test_prime_lengths(self):
        # Prime lengths: 2, 3, 5, 7, 11
        for length in [2, 3, 5, 7, 11]:
            tm = TuringMachine("1" * length)
            self.assertTrue(tm.run(), f"Length {length} should be prime")

    def test_non_prime_lengths(self):
        # Non-prime lengths: 1, 4, 6, 8, 9, 10, 12
        for length in [1, 4, 6, 8, 9, 10, 12]:
            tm = TuringMachine("1" * length)
            self.assertFalse(tm.run(), f"Length {length} should NOT be prime")

if __name__ == '__main__':
    unittest.main()
