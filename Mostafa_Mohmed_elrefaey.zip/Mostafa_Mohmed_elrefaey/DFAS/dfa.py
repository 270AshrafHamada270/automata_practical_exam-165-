# Class to represent a Deterministic Finite Automaton (DFA)
class DFA:
    def __init__(self, states, alphabet, transition, start_state, accept_states):
        self.states = states                 # A list of all states in the DFA
        self.alphabet = alphabet             # A list of input symbols (alphabet)
        self.transition = transition         # A dictionary representing the transition function
        self.start_state = start_state       # The start state of the DFA
        self.accept_states = accept_states   # A list of accept (final) states

# Function to check whether two DFAs are equivalent 
def are_equivalent(dfa1, dfa2):
    visited = []     # List to track visited pairs of states 
    queue = []       # Queue for Breadth-First Search

    start = (dfa1.start_state, dfa2.start_state)  # Start from the initial states of both DFAs
    queue.append(start)
    visited.append(start)

    while queue:
        state1, state2 = queue.pop(0)  # Get the next state pair to process

        # Check if one DFA is in an accepting state and the other is not
        is_accepting1 = state1 in dfa1.accept_states
        is_accepting2 = state2 in dfa2.accept_states

        if is_accepting1 != is_accepting2:
            return False  # DFAs are not equivalent if they disagree on accepting a string

        # Process all symbols in the shared alphabet
        for symbol in dfa1.alphabet:
            if symbol in dfa2.alphabet:
                next1 = dfa1.transition.get((state1, symbol))  # Next state in DFA1
                next2 = dfa2.transition.get((state2, symbol))  # Next state in DFA2

                if next1 is None or next2 is None:
                    continue  # Skip if either DFA lacks a transition for this symbol

                pair = (next1, next2)
                if pair not in visited:
                    visited.append(pair)      # Mark the pair as visited
                    queue.append(pair)        # Add to queue for further exploration

    return True  # All paths checked without mismatch, DFAs are equivalent
