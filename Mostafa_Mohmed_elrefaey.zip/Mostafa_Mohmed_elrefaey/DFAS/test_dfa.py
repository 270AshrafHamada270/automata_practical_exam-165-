# test_dfa.py

import unittest
from dfa import DFA, are_equivalent # type: ignore

class TestDFAEquivalence(unittest.TestCase):

    def test_equivalent_dfas(self):
        dfa1 = DFA(
            states=['q0', 'q1'],
            alphabet=['a', 'b'],
            transition={
                ('q0', 'a'): 'q1',
                ('q0', 'b'): 'q0',
                ('q1', 'a'): 'q0',
                ('q1', 'b'): 'q1'
            },
            start_state='q0',
            accept_states=['q0']
        )

        dfa2 = DFA(
            states=['s0', 's1'],
            alphabet=['a', 'b'],
            transition={
                ('s0', 'a'): 's1',
                ('s0', 'b'): 's0',
                ('s1', 'a'): 's0',
                ('s1', 'b'): 's1'
            },
            start_state='s0',
            accept_states=['s0']
        )

        self.assertTrue(are_equivalent(dfa1, dfa2))

    def test_non_equivalent_dfas(self):
        dfa1 = DFA(
            states=['q0', 'q1'],
            alphabet=['a'],
            transition={
                ('q0', 'a'): 'q1',
                ('q1', 'a'): 'q0'
            },
            start_state='q0',
            accept_states=['q0']
        )

        dfa2 = DFA(
            states=['s0', 's1'],
            alphabet=['a'],
            transition={
                ('s0', 'a'): 's1',
                ('s1', 'a'): 's0'
            },
            start_state='s0',
            accept_states=['s1']
        )

        self.assertFalse(are_equivalent(dfa1, dfa2))

if __name__ == '__main__':
    unittest.main()
