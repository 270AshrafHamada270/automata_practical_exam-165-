import unittest
from cyk import cyk_algorithm

class TestCYKAlgorithm(unittest.TestCase):
    def setUp(self):
        self.grammar = {
            'S': [['B', 'C'], ['A', 'B']],
            'A': [['a']],
            'B': [['b']],
            'C': [['A', 'S']]
        }
        self.start_symbol = 'S'

    def test_valid_string(self):
        self.assertTrue(cyk_algorithm("baab", self.grammar, self.start_symbol))

    def test_invalid_string(self):
        self.assertFalse(cyk_algorithm("aaaa", self.grammar, self.start_symbol))

    def test_empty_string(self):
        self.assertFalse(cyk_algorithm("", self.grammar, self.start_symbol))

    def test_single_character(self):
        self.assertFalse(cyk_algorithm("a", self.grammar, self.start_symbol))

if __name__ == '__main__':
    unittest.main()
